def get():
    print("Ger rates touched")
    