from setuptools import setup, find_packages

setup(name="fixer",
      version="0.1",
      license="MIT",
      packages=["fixer"]
      )